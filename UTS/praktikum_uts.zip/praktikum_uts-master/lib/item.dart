class Item {
  String name;
  int price;
  int stock;
  String image;
  double rating;

  Item({required this.name, required this.price, required this.stock, required this.image, required this.rating});
}
