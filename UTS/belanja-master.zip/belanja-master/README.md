# NAMA : FARHAN RAMAZAIN
# KELAS : TI-3G
# NIM : 2141720209
## UTS

# PRAKTIKUM 5

## Langkah 1
![](ss/l1.png)
## Langkah 2
![](ss/l2.png)
![](ss/l2,1.png)
## Langkah 3
![](ss/l3.png)
## Langkah 4
![](ss/l4.png)
## Output
![](ss/op1.png)
![](ss/op2.png)

# Tugas Praktikum 2

## Langkah 1
![](ss/t1.png)
## Langkah 2
![](ss/t2.png)
![](ss/t2,1.png)
## Langkah 3
![](ss/t3.png)
## Langkah 4
![](ss/t4.png)
## Output
![](ss/op3.png)
![](ss/op4.png)
